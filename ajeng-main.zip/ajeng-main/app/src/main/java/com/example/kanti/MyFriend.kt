package com.example.kanti

class MyFriend (
    val nama:String,
    val jkel:String,
    val email:String,
    val telp:String,
    val alamat:String,

    )